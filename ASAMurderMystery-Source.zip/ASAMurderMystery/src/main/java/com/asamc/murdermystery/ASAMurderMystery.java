package com.asamc.murdermystery;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** ASAMC Mystery: a role-based deduction minigame with discussion and voting. */
public final class ASAMurderMystery extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private final Map<UUID, String> playerArena = new ConcurrentHashMap<>();
    private final Map<UUID, String> roles = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> gold = new ConcurrentHashMap<>();
    private final Map<UUID, ItemStack[]> savedInventories = new ConcurrentHashMap<>();
    private final Map<UUID, GameMode> savedModes = new ConcurrentHashMap<>();
        private final Map<UUID, Integer> statsWins = new ConcurrentHashMap<>();
    private final NamespacedKey goldKey = new NamespacedKey(this, "mm_gold");
    private File arenaFile, messageFile;
    private YamlConfiguration arenasYaml, messages;
    private Connection database;

    private enum State { WAITING, STARTING, INGAME, ENDING, RESETTING }
    private static final class Arena {
        final String name;
        State state = State.WAITING;
        Location lobby, waiting;
        final List<Location> spawns = new ArrayList<>(), goldSpawns = new ArrayList<>();
        final Set<UUID> players = new LinkedHashSet<>();
        final Set<UUID> spectators = new LinkedHashSet<>();
        final Map<UUID, Integer> votes = new HashMap<>();
        final Map<UUID, UUID> ballots = new HashMap<>();
        int countdown, timeLeft;
        BukkitTask task;
        Arena(String name) { this.name = name; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false); saveResource("arenas.yml", false); saveResource("rewards.yml", false);
        messageFile = new File(getDataFolder(), "messages.yml"); messages = YamlConfiguration.loadConfiguration(messageFile);
        arenaFile = new File(getDataFolder(), "arenas.yml"); arenasYaml = YamlConfiguration.loadConfiguration(arenaFile);
        loadArenas(); openDatabase();
        Objects.requireNonNull(getCommand("mm")).setExecutor(this); Objects.requireNonNull(getCommand("mm")).setTabCompleter(this);
        for (String cmd : List.of("setgoldspawn", "setplayerspawn")) { PluginCommand c = getCommand(cmd); if (c != null) c.setExecutor(this); }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ASAMurderMystery enabled. Loaded " + arenas.size() + " arena(s).");
    }
    @Override public void onDisable() {
        for (Arena a : arenas.values()) { if (a.task != null) a.task.cancel(); for (UUID id : a.players) { Player p = Bukkit.getPlayer(id); if (p != null) restorePlayer(p); } }
        saveArenas(); try { if (database != null && !database.isClosed()) database.close(); } catch (SQLException ignored) {}
    }
    private void openDatabase() {
        try { File db = new File(getDataFolder(), "stats.db"); database = DriverManager.getConnection("jdbc:sqlite:" + db.getAbsolutePath());
            try (Statement s = database.createStatement()) { s.executeUpdate("CREATE TABLE IF NOT EXISTS stats(uuid TEXT PRIMARY KEY, wins INTEGER DEFAULT 0, games INTEGER DEFAULT 0, votes INTEGER DEFAULT 0, gold INTEGER DEFAULT 0)"); }
        } catch (SQLException e) { getLogger().severe("SQLite initialization failed: " + e.getMessage()); }
    }
    private void loadArenas() {
        ConfigurationSection root = arenasYaml.getConfigurationSection("arenas"); if (root == null) return;
        for (String name : root.getKeys(false)) { ConfigurationSection s = root.getConfigurationSection(name); if (s == null) continue; Arena a = new Arena(name.toLowerCase(Locale.ROOT));
            a.lobby = readLoc(s.getConfigurationSection("lobby")); a.waiting = readLoc(s.getConfigurationSection("waiting"));
            for (String k : s.getStringList("spawns")) { Location l = readLocString(k); if (l != null) a.spawns.add(l); }
            for (String k : s.getStringList("gold-spawns")) { Location l = readLocString(k); if (l != null) a.goldSpawns.add(l); }
            arenas.put(a.name, a);
        }
    }
    private Location readLoc(ConfigurationSection s) { if (s == null) return null; return new Location(Bukkit.getWorld(s.getString("world", "world")), s.getDouble("x"), s.getDouble("y"), s.getDouble("z"), (float)s.getDouble("yaw"), (float)s.getDouble("pitch")); }
    private Location readLocString(String v) { try { String[] p=v.split(","); World w=Bukkit.getWorld(p[0]); if(w==null)return null; return new Location(w,Double.parseDouble(p[1]),Double.parseDouble(p[2]),Double.parseDouble(p[3]),Float.parseFloat(p[4]),Float.parseFloat(p[5])); } catch(Exception e){return null;} }
    private String locString(Location l) { return l.getWorld().getName()+","+l.getX()+","+l.getY()+","+l.getZ()+","+l.getYaw()+","+l.getPitch(); }
    private void saveArenas() { arenasYaml.set("arenas", null); for(Arena a:arenas.values()){ String b="arenas."+a.name; if(a.lobby!=null)writeLoc(b+".lobby",a.lobby); if(a.waiting!=null)writeLoc(b+".waiting",a.waiting); arenasYaml.set(b+".spawns",a.spawns.stream().map(this::locString).toList()); arenasYaml.set(b+".gold-spawns",a.goldSpawns.stream().map(this::locString).toList()); } try{arenasYaml.save(arenaFile);}catch(Exception e){getLogger().warning("Could not save arenas: "+e.getMessage());} }
    private void writeLoc(String path, Location l) { arenasYaml.set(path+".world",l.getWorld().getName()); arenasYaml.set(path+".x",l.getX()); arenasYaml.set(path+".y",l.getY()); arenasYaml.set(path+".z",l.getZ()); arenasYaml.set(path+".yaw",l.getYaw()); arenasYaml.set(path+".pitch",l.getPitch()); }
    private Component msg(String key) { return mm.deserialize(messages.getString(key,"<red>Missing message: "+key)); }
    private void send(CommandSender sender,String key) { sender.sendMessage(msg(key).replaceText(net.kyori.adventure.text.TextReplacementConfig.builder().matchLiteral("%prefix%").replacement(messages.getString("prefix","")).build())); }
    private void tell(Player p, String key) { p.sendMessage(msg(key)); }
    private boolean admin(CommandSender s) { if(s.hasPermission("asamm.admin"))return true; s.sendMessage(msg("no-permission")); return false; }
    private Arena arena(String name) { return arenas.get(name.toLowerCase(Locale.ROOT)); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(command.getName().equalsIgnoreCase("setgoldspawn") || command.getName().equalsIgnoreCase("setplayerspawn")) {
            if(!admin(sender))return true; if(!(sender instanceof Player p)){send(sender,"player-only");return true;} String edit=p.getMetadata("asamm_edit").stream().findFirst().map(m->m.asString()).orElse(""); Arena a=arena(edit); if(a==null){p.sendMessage(mm.deserialize("<red>Set editing arena first: /mm arena edit <name>"));return true;}
            if(command.getName().equalsIgnoreCase("setgoldspawn")){a.goldSpawns.add(p.getLocation().getBlock().getLocation().add(.5,0,.5));p.sendMessage(mm.deserialize("<green>Gold spawn added. Total: "+a.goldSpawns.size()));}else{a.spawns.add(p.getLocation());p.sendMessage(mm.deserialize("<green>Player spawn added. Total: "+a.spawns.size()));}saveArenas();return true;
        }
        if(args.length==0){help(sender);return true;} String sub=args[0].toLowerCase(Locale.ROOT);
        if(sub.equals("help")){help(sender);return true;}
        if(sub.equals("join")){if(!(sender instanceof Player p)){send(sender,"player-only");return true;} if(!p.hasPermission("asamm.join")){send(sender,"no-permission");return true;} if(args.length<2){p.sendMessage(mm.deserialize("<yellow>/mm join <arena>"));return true;} join(p,args[1]);return true;}
        if(sub.equals("leave")){if(sender instanceof Player p)leave(p);else send(sender,"player-only");return true;}
        if(sub.equals("vote")){if(sender instanceof Player p && args.length>1)vote(p,args[1]);else sender.sendMessage(mm.deserialize("<yellow>/mm vote <player>"));return true;}
        if(sub.equals("stats")){if(sender instanceof Player p)showStats(p);else sender.sendMessage("Stats are player-only.");return true;}
        if(sub.equals("top")){showTop(sender);return true;}
        if(sub.equals("gui")){if(sender instanceof Player p)openArenaGui(p);return true;}
        if(sub.equals("arena")){if(!admin(sender))return true; arenaCommand(sender,args);return true;}
        if(sub.equals("setlobby")){if(!admin(sender))return true;if(!(sender instanceof Player p))return true;if(args.length<2){p.sendMessage(mm.deserialize("<yellow>/mm setlobby <arena>"));return true;}Arena a=arena(args[1]);if(a==null){send(p,"unknown-arena");return true;}a.lobby=p.getLocation();saveArenas();p.sendMessage(mm.deserialize("<green>Lobby saved."));return true;}
        if(sub.equals("start")||sub.equals("forcestart")||sub.equals("stop")){if(!admin(sender))return true;if(args.length<2){sender.sendMessage("/mm "+sub+" <arena>");return true;}Arena a=arena(args[1]);if(a==null){send(sender,"unknown-arena");return true;}if(sub.equals("stop"))end(a,false);else start(a,true);return true;}
        if(sub.equals("reload")){if(!admin(sender))return true;reloadConfig();messages=YamlConfiguration.loadConfiguration(messageFile);sender.sendMessage(mm.deserialize("<green>ASAMM configuration reloaded."));return true;}
        if(sub.equals("setwaiting")){if(!admin(sender)||!(sender instanceof Player p)||args.length<2)return true;Arena a=arena(args[1]);if(a==null){send(p,"unknown-arena");return true;}a.waiting=p.getLocation();saveArenas();p.sendMessage(mm.deserialize("<green>Waiting location saved."));return true;}
        return true;
    }
    private void arenaCommand(CommandSender s,String[] a){if(a.length<2){s.sendMessage(mm.deserialize("<yellow>/mm arena create|delete|list|info|edit <name>"));return;}String action=a[1].toLowerCase(Locale.ROOT);if(action.equals("list")){s.sendMessage(mm.deserialize("<gold>Arenas: <white>"+String.join(", ",arenas.keySet())));return;}if(a.length<3){s.sendMessage(mm.deserialize("<yellow>/mm arena "+action+" <name>"));return;}String name=a[2].toLowerCase(Locale.ROOT);switch(action){case "create"->{if(arenas.containsKey(name)){s.sendMessage(mm.deserialize("<red>Already exists."));return;}arenas.put(name,new Arena(name));saveArenas();s.sendMessage(mm.deserialize("<green>Arena created: "+name));}case "delete"->{Arena ar=arena(name);if(ar==null){send(s,"unknown-arena");return;}end(ar,false);arenas.remove(name);saveArenas();s.sendMessage(mm.deserialize("<green>Arena deleted."));}case "list"->{s.sendMessage(mm.deserialize("<gold>Arenas: <white>"+String.join(", ",arenas.keySet())));}case "info"->{Arena ar=arena(name);if(ar==null){send(s,"unknown-arena");return;}s.sendMessage(mm.deserialize("<gold>"+name+" <gray>state=<white>"+ar.state+" <gray>spawns=<white>"+ar.spawns.size()+" <gray>gold=<white>"+ar.goldSpawns.size()+" <gray>players=<white>"+ar.players.size()));}case "setspawn","setgoldspawn"->{if(!(s instanceof Player p)){send(s,"player-only");return;}Arena ar=arena(name);if(ar==null){send(s,"unknown-arena");return;}if(action.equals("setspawn"))ar.spawns.add(p.getLocation());else ar.goldSpawns.add(p.getLocation().getBlock().getLocation().add(.5,0,.5));saveArenas();p.sendMessage(mm.deserialize("<green>Location saved for "+name));}case "edit"->{if(s instanceof Player p){if(arena(name)==null){send(s,"unknown-arena");return;}p.setMetadata("asamm_edit",new org.bukkit.metadata.FixedMetadataValue(this,name));p.sendMessage(mm.deserialize("<green>Editing arena "+name+". Use /setplayerspawn and /setgoldspawn."));}}default->s.sendMessage("Unknown arena action.");}}
    private void help(CommandSender s){s.sendMessage(mm.deserialize("<gold><bold>ASAMC MurderMystery</bold><newline><yellow>/mm gui <gray>- Arena selector<newline><yellow>/mm join <arena><newline><yellow>/mm leave<newline><yellow>/mm vote <player><newline><yellow>/mm stats | top<newline><yellow>/mm arena create|delete|list|info|edit <name><newline><yellow>/mm setlobby <arena><newline><yellow>/mm setwaiting <arena><newline><yellow>/mm start|stop <arena><newline><yellow>/setplayerspawn <gray>- after /mm arena edit <name><newline><yellow>/setgoldspawn"));}
    private void join(Player p,String name){Arena a=arena(name);if(a==null){tell(p,"unknown-arena");return;}if(playerArena.containsKey(p.getUniqueId())){tell(p,"already-playing");return;}int max=getConfig().getInt("settings.max-players",16);if(a.state!=State.WAITING&&a.state!=State.STARTING||a.players.size()>=max){p.sendMessage(mm.deserialize("<red>This arena is not accepting players."));return;}a.players.add(p.getUniqueId());playerArena.put(p.getUniqueId(),a.name);gold.put(p.getUniqueId(),0);savedInventories.put(p.getUniqueId(),p.getInventory().getContents().clone());savedModes.put(p.getUniqueId(),p.getGameMode());p.getInventory().clear();if(a.waiting!=null)p.teleport(a.waiting);tell(p,"joined");p.sendMessage(mm.deserialize("<gray>Use <yellow>/mm leave <gray>to leave. Round starts when enough players join."));if(a.players.size()>=getConfig().getInt("settings.min-players",3)&&a.state==State.WAITING)countdown(a);updateBoards(a);}
    private void leave(Player p){String n=playerArena.remove(p.getUniqueId());if(n==null){p.sendMessage(mm.deserialize("<red>You are not in a game."));return;}Arena a=arena(n);roles.remove(p.getUniqueId());gold.remove(p.getUniqueId());restorePlayer(p);p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());if(a!=null){a.players.remove(p.getUniqueId());a.spectators.remove(p.getUniqueId());a.ballots.remove(p.getUniqueId());a.votes.clear();for(UUID target:a.ballots.values())a.votes.merge(target,1,Integer::sum);if(a.players.isEmpty()){if(a.task!=null)a.task.cancel();a.state=State.WAITING;}else if(a.state==State.INGAME)checkWin(a);updateBoards(a);}tell(p,"left");if(a!=null&&a.lobby!=null&&p.isOnline())p.teleport(a.lobby);}
    private void start(Arena a,boolean force){if(a.state==State.INGAME||a.state==State.ENDING||a.state==State.RESETTING){broadcast(a,"<red>This arena is already running.");return;}int minimum=getConfig().getInt("settings.min-players",3);if(a.players.size()<minimum&&!force){broadcast(a,"<red>Not enough players to start.");return;}if(a.players.size()<2){broadcast(a,"<red>At least two players are required.");return;}if(a.task!=null)a.task.cancel();begin(a);}
    private void countdown(Arena a){a.state=State.STARTING;a.countdown=getConfig().getInt("settings.countdown-seconds",15);a.task=Bukkit.getScheduler().runTaskTimer(this,()->{if(a.players.size()<getConfig().getInt("settings.min-players",3)){a.state=State.WAITING;a.task.cancel();return;}if(a.countdown<=0){a.task.cancel();begin(a);return;}broadcast(a,"<green>Game starts in <yellow>"+a.countdown+"<green> seconds!");a.countdown--;},0,20);}
    private void begin(Arena a){if(a.players.size()<getConfig().getInt("settings.min-players",3)){a.state=State.WAITING;return;}a.state=State.INGAME;a.timeLeft=getConfig().getInt("settings.game-seconds",240);a.votes.clear();a.ballots.clear();List<UUID> ids=new ArrayList<>(a.players);Collections.shuffle(ids);UUID mystery=ids.getFirst();UUID detective=ids.size()>1?ids.get(1):mystery;for(UUID id:ids){String role=id.equals(mystery)?"MURDERER":id.equals(detective)?"DETECTIVE":"INNOCENT";roles.put(id,role);Player p=Bukkit.getPlayer(id);if(p!=null){p.getInventory().clear();p.setGameMode(GameMode.ADVENTURE);p.sendMessage(mm.deserialize("<gray>Your role: "+(role.equals("MURDERER")?"<red><bold>MYSTERY":role.equals("DETECTIVE")?"<aqua><bold>DETECTIVE":"<green><bold>INNOCENT")));p.sendMessage(mm.deserialize("<yellow>Discuss, collect tokens, and vote with /mm vote <player>."));if(!a.spawns.isEmpty())p.teleport(a.spawns.get(new Random().nextInt(a.spawns.size())));}}broadcast(a,"<gold>The mystery round has started!");updateBoards(a);a.task=Bukkit.getScheduler().runTaskTimer(this,()->{if(a.state!=State.INGAME)return;if(a.timeLeft<=0){end(a,false);return;}a.timeLeft--;if(a.timeLeft%getConfig().getInt("settings.voting-seconds",25)==0){broadcast(a,"<yellow>Voting is open! Use /mm vote <player>.");a.votes.clear();a.ballots.clear();}spawnGold(a);updateBoards(a);},20,20);}
    private void spawnGold(Arena a){if(a.goldSpawns.isEmpty())return;for(Location l:a.goldSpawns){if(l.getWorld()==null)continue;boolean exists=l.getWorld().getNearbyEntities(l,0.5,0.5,0.5).stream().anyMatch(e->e instanceof org.bukkit.entity.Item item&&isGold(item.getItemStack()));if(!exists){ItemStack stack=new ItemStack(Material.GOLD_NUGGET);ItemMeta meta=stack.getItemMeta();meta.displayName(mm.deserialize("<gold>Mystery Token"));meta.getPersistentDataContainer().set(goldKey,PersistentDataType.BYTE,(byte)1);stack.setItemMeta(meta);l.getWorld().dropItemNaturally(l,stack);}}}
    private boolean isGold(ItemStack s){return s!=null&&s.hasItemMeta()&&s.getItemMeta().getPersistentDataContainer().has(goldKey,PersistentDataType.BYTE);}
    private void vote(Player p,String target){Arena a=playerArena.containsKey(p.getUniqueId())?arena(playerArena.get(p.getUniqueId())):null;if(a==null||a.state!=State.INGAME){p.sendMessage(mm.deserialize("<red>You are not in an active round."));return;}Player t=Bukkit.getPlayerExact(target);if(t==null||!a.players.contains(t.getUniqueId())||t.equals(p)){tell(p,"invalid-vote");return;}a.ballots.put(p.getUniqueId(),t.getUniqueId());a.votes.clear();for(UUID targetId:a.ballots.values())a.votes.merge(targetId,1,Integer::sum);tell(p,"vote-cast");if(a.ballots.size()>=a.players.size())resolveVote(a);}
    private void resolveVote(Arena a){if(a.votes.isEmpty()){broadcast(a,"<gray>No votes were cast.");a.ballots.clear();return;}UUID chosen=a.votes.entrySet().stream().max(Map.Entry.comparingByValue()).orElseThrow().getKey();Player p=Bukkit.getPlayer(chosen);String role=roles.getOrDefault(chosen,"UNKNOWN");broadcast(a,"<yellow>"+(p==null?"A player":p.getName())+" was voted out. Role: "+role+".");if("MURDERER".equals(role)){end(a,true);}else{a.players.remove(chosen);a.spectators.add(chosen);roles.remove(chosen);if(p!=null){p.setGameMode(GameMode.SPECTATOR);p.sendMessage(mm.deserialize("<gray>You are now spectating."));}checkWin(a);}a.votes.clear();a.ballots.clear();}
    private void checkWin(Arena a){long alive=a.players.stream().filter(id->roles.containsKey(id)).count();long mystery=a.players.stream().filter(id->"MURDERER".equals(roles.get(id))).count();if(mystery==0)end(a,true);else if(alive<=1)end(a,false);}
    private void end(Arena a,boolean solved){if(a.task!=null)a.task.cancel();if(a.state==State.WAITING&&a.players.isEmpty())return;a.state=State.ENDING;broadcast(a,solved?"<green>The mystery has been solved! Innocents win.":"<red>The hidden player wins!");Set<UUID> participants=new LinkedHashSet<>(a.players);participants.addAll(a.spectators);for(UUID id:participants){Player p=Bukkit.getPlayer(id);if(p!=null){boolean won=solved?!"MURDERER".equals(roles.get(id)):"MURDERER".equals(roles.get(id));recordGame(id,won);restorePlayer(p);p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());if(a.lobby!=null)p.teleport(a.lobby);p.sendMessage(mm.deserialize("<gray>Round ended. Thanks for playing!"));}playerArena.remove(id);roles.remove(id);gold.remove(id);}a.players.clear();a.spectators.clear();cleanupGold(a);a.votes.clear();a.ballots.clear();a.state=State.WAITING;}
    private void restorePlayer(Player p){ItemStack[] contents=savedInventories.remove(p.getUniqueId());if(contents!=null)p.getInventory().setContents(contents);GameMode mode=savedModes.remove(p.getUniqueId());if(mode!=null)p.setGameMode(mode);}
    private void cleanupGold(Arena a){for(Location l:a.goldSpawns){if(l.getWorld()==null)continue;for(org.bukkit.entity.Entity e:l.getWorld().getNearbyEntities(l,1.5,1.5,1.5)){if(e instanceof org.bukkit.entity.Item item&&isGold(item.getItemStack()))e.remove();}}}
    private void recordGame(UUID id,boolean win){if(database==null)return;Bukkit.getScheduler().runTaskAsynchronously(this,()->{synchronized(this){try(PreparedStatement ps=database.prepareStatement("INSERT INTO stats(uuid,wins,games) VALUES(?,?,1) ON CONFLICT(uuid) DO UPDATE SET wins=wins+excluded.wins,games=games+1")){ps.setString(1,id.toString());ps.setInt(2,win?1:0);ps.executeUpdate();}catch(SQLException e){getLogger().warning("Stats save failed: "+e.getMessage());}}});}
    private void broadcast(Arena a,String text){for(UUID id:a.players){Player p=Bukkit.getPlayer(id);if(p!=null)p.sendMessage(mm.deserialize(text));}}
    private void updateBoards(Arena a){for(UUID id:a.players){Player p=Bukkit.getPlayer(id);if(p==null)continue;org.bukkit.scoreboard.Scoreboard board=Bukkit.getScoreboardManager().getNewScoreboard();org.bukkit.scoreboard.Objective o=board.registerNewObjective("asamm","dummy",mm.deserialize(getConfig().getString("scoreboard.title","<gold>ASAMC MURDERMYSTERY")));o.setDisplaySlot(org.bukkit.scoreboard.DisplaySlot.SIDEBAR);List<String> lines=getConfig().getStringList("scoreboard.lines");int score=lines.size();for(String line:lines){line=line.replace("%arena%",a.name).replace("%role%",roles.getOrDefault(id,"WAITING")).replace("%players%",String.valueOf(a.players.size())).replace("%max%",String.valueOf(getConfig().getInt("settings.max-players",16))).replace("%gold%",String.valueOf(gold.getOrDefault(id,0))).replace("%time%",String.format("%02d:%02d",a.timeLeft/60,a.timeLeft%60));String entry=ChatColor.values()[score%ChatColor.values().length].toString()+ChatColor.RESET;org.bukkit.scoreboard.Team team=board.registerNewTeam("line"+score);team.addEntry(entry);team.prefix(mm.deserialize(line));o.getScore(entry).setScore(score--);}p.setScoreboard(board);}}
    private void openArenaGui(Player p){Inventory inv=Bukkit.createInventory(null,27,mm.deserialize("<gold>ASAMC • Arena Selector"));int slot=10;for(Arena a:arenas.values()){if(slot>16)break;ItemStack it=new ItemStack(Material.PAPER);ItemMeta m=it.getItemMeta();m.displayName(mm.deserialize("<yellow>"+a.name));m.lore(List.of(mm.deserialize("<gray>State: <white>"+a.state),mm.deserialize("<gray>Players: <white>"+a.players.size()),mm.deserialize("<green>Click to join")));m.getPersistentDataContainer().set(new NamespacedKey(this,"arena"),PersistentDataType.STRING,a.name);it.setItemMeta(m);inv.setItem(slot++,it);}p.openInventory(inv);}
    @EventHandler public void onInventory(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;if(!e.getView().title().equals(mm.deserialize("<gold>ASAMC • Arena Selector")))return;e.setCancelled(true);ItemStack it=e.getCurrentItem();if(it==null||!it.hasItemMeta())return;String a=it.getItemMeta().getPersistentDataContainer().get(new NamespacedKey(this,"arena"),PersistentDataType.STRING);if(a!=null){p.closeInventory();join(p,a);}}
    @EventHandler public void onPickup(org.bukkit.event.entity.EntityPickupItemEvent e){if(!(e.getEntity() instanceof Player p)||!isGold(e.getItem().getItemStack()))return;String n=playerArena.get(p.getUniqueId());if(n==null||arena(n)==null||arena(n).state!=State.INGAME){e.setCancelled(true);return;}int amount=gold.merge(p.getUniqueId(),getConfig().getInt("settings.gold-value",1),Integer::sum);e.getItem().remove();e.setCancelled(true);p.sendActionBar(mm.deserialize("<gold>Gold: "+amount));}
    @EventHandler public void onDrop(PlayerDropItemEvent e){if(isGold(e.getItemDrop().getItemStack()))e.setCancelled(true);}
    @EventHandler public void onDamage(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&playerArena.containsKey(p.getUniqueId()))e.setCancelled(true);}
    @EventHandler public void onQuit(PlayerQuitEvent e){if(playerArena.containsKey(e.getPlayer().getUniqueId()))leave(e.getPlayer());}
    @EventHandler public void onInteract(PlayerInteractEvent e){if(e.getAction()!=Action.RIGHT_CLICK_AIR&&e.getAction()!=Action.RIGHT_CLICK_BLOCK)return;}
    private void showStats(Player p){if(database==null){p.sendMessage(mm.deserialize("<red>Stats database unavailable."));return;}Bukkit.getScheduler().runTaskAsynchronously(this,()->{try(PreparedStatement ps=database.prepareStatement("SELECT wins,games FROM stats WHERE uuid=?")){ps.setString(1,p.getUniqueId().toString());try(ResultSet rs=ps.executeQuery()){int w=rs.next()?rs.getInt(1):0,g=rs.getInt(2);Bukkit.getScheduler().runTask(this,()->p.sendMessage(mm.deserialize("<gold>Your stats: <white>Wins "+w+" <gray>| <white>Games "+g)));}}catch(SQLException ex){getLogger().warning(ex.getMessage());}});}
    private void showTop(CommandSender sender){if(database==null){sender.sendMessage("Database unavailable.");return;}Bukkit.getScheduler().runTaskAsynchronously(this,()->{StringBuilder out=new StringBuilder("<gold>ASAMC Leaderboard");try(Statement s=database.createStatement();ResultSet rs=s.executeQuery("SELECT uuid,wins FROM stats ORDER BY wins DESC LIMIT 10")){while(rs.next()){OfflinePlayer op=Bukkit.getOfflinePlayer(UUID.fromString(rs.getString(1)));out.append("<newline><yellow>").append(op.getName()==null?"Unknown":op.getName()).append(" <gray>- <white>").append(rs.getInt(2));}}catch(Exception ex){getLogger().warning(ex.getMessage());}String result=out.toString();Bukkit.getScheduler().runTask(this,()->sender.sendMessage(mm.deserialize(result)));});}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){if(args.length==1)return List.of("join","leave","vote","stats","top","gui","arena","start","forcestart","stop","setlobby","setwaiting","reload","help").stream().filter(x->x.startsWith(args[0].toLowerCase())).toList();if(args.length==2&&List.of("join","start","forcestart","stop","setlobby","setwaiting").contains(args[0]))return arenas.keySet().stream().toList();return List.of();}
}

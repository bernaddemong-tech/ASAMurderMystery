# ASAMurderMystery 1.0.0 — ASAMC

An original Paper plugin project for a crossplay-friendly, role-based mystery minigame. Players receive hidden roles, gather mystery tokens, discuss, and vote. The implementation intentionally uses a deduction/voting loop rather than combat or weapon mechanics.

## Target
- PaperMC / Minecraft 26.3 API
- Java 25
- Maven
- Geyser-compatible server-side commands, inventory UI, Adventure text, and ordinary vanilla items

## Build
Requirements: JDK 25 and Maven 3.9+ with internet access.

```bash
mvn clean package
```

The shaded plugin jar will be in `target/ASAMurderMystery-1.0.0.jar`.

> This workspace only has Java 21 and does not have Maven installed, so a Paper 26.3 JAR could not be compiled or runtime-tested here. Do not put this source ZIP directly into `plugins/`; build it first with JDK 25 + Maven.

## Install
1. Build the project using the command above.
2. Upload `target/ASAMurderMystery-1.0.0.jar` to the server's `plugins/` folder.
3. Restart Paper.
4. Configure `plugins/ASAMurderMystery/config.yml` and `messages.yml`.
5. Create and configure an arena using the commands below.

## Arena setup
Run as an operator:

```text
/mm arena create museum
/mm arena edit museum
/setplayerspawn
/setplayerspawn
/setgoldspawn
/mm setwaiting museum
/mm setlobby museum
/mm arena info museum
```

`/setplayerspawn` and `/setgoldspawn` add the current location to the arena currently selected with `/mm arena edit <name>`. Set at least as many player spawns as the expected simultaneous players. Gold token spawn points are optional.

## Commands
### Player
- `/mm gui` — open the arena selector
- `/mm join <arena>`
- `/mm leave`
- `/mm vote <player>` — cast a vote during an active round
- `/mm stats`
- `/mm top`
- `/mm help`

### Admin (`asamm.admin`)
- `/mm arena create <name>`
- `/mm arena delete <name>`
- `/mm arena list`
- `/mm arena info <name>`
- `/mm arena edit <name>`
- `/mm arena setspawn <name>`
- `/mm arena setgoldspawn <name>`
- `/mm setwaiting <name>`
- `/mm setlobby <name>`
- `/mm start <arena>` or `/mm forcestart <arena>`
- `/mm stop <arena>`
- `/mm reload`
- `/setplayerspawn` and `/setgoldspawn`

### Permissions
- `asamm.admin` — operator by default
- `asamm.join` — everyone by default
- `asamm.stats` — everyone by default (reserved for stats access control)

## Data files
- `config.yml` — player limits, timers, gold token settings, scoreboard layout
- `messages.yml` — MiniMessage-formatted messages
- `arenas.yml` — saved arena locations
- `rewards.yml` — initial reward settings (not yet wired into payout logic)
- `stats.db` — SQLite win/game counters

## Current implementation status
Implemented in this first source build:
- Multi-arena storage and setup commands
- Waiting / starting / in-game / ending flow
- Random hidden Mystery, Detective, and Innocent roles
- Player spawn points and waiting/lobby teleports
- Collectible token drops at configured points
- Arena selector GUI
- Configurable sidebar scoreboard
- Voting and round winner resolution
- SQLite games/wins counters, stats display, top list
- Inventory and game-mode snapshot/restore on normal leave and round end
- Damage disabled for players while they are in a minigame arena

Not implemented yet:
- Combat-based elimination or weapon items
- Shop purchases / clue shop
- Bounds / region protection and world rollback reset
- Voting phase timer / automatic vote resolution when the voting timer expires
- Full per-stat tracking (kills, deaths, gold totals, role-specific wins)
- Reward payout integration from `rewards.yml`
- Floodgate / PlaceholderAPI hooks (not required for basic Geyser compatibility)
- Complete automated tests and live Paper 26.3 testing

This is a functional starting source project, not a claim that every item in the original feature wish-list is finished. Review and test it on a staging server before using it on a live network.
